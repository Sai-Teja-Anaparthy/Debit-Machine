/* USER CODE BEGIN Header */
/** FILE          : main.c
 PROJECT       : PROG8125
 PROGRAMMER    : R. Hofer
 FIRST VERSION : 2016-02-0
 REVISED:	   : 2017-01-23 - Changed to run on the Nucleo-32 and in TrueSTUDIO
 REVISED:	   : 2019-03-27 Allan Smith - Changed to work with v 9.20 of TrueSTUDIO and cubemx32 5.1
 	 	 	 	 and fix a number of minor issues
 	 	 	 	 2020-11-18 Allan Smith - fixed to work with CubeMx ide 1.4.2
 DESCRIPTION   : Demonstrates a debit machine banking transaction that implements a state machine.


 Switches are assigned as follows
 note: these pins are set in the debounceInit functions and do not need to be configured in cube
 PA0			PA1			PA4			PA3
 chequing		savings		ok			cancel

 Note: Don't use PA2 as it is connected to VCP TX and you'll
 lose printf output ability.


 ******************************************************************************
 * @file           : main.c
 * @brief          : Debit Machine
 * @Programmer     : SAI TEJA ANAPARTHY
 * @Date           : 05/12/2020
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <unistd.h>
#include <stdio.h>
#include "stm32l4xx_hal.h"
#include "debounce.h"
#include "HD44780.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static const int16_t chequingPbPin = 0; //setting the pin assigned to each pb
static const int16_t savingsPbPin = 1;		//don't use pin 2 as it's connected
static const int16_t okPbPin = 4;		//to VCP TX
static const int16_t cancelPbPin = 3;

int8_t transactionState = 1;
int16_t pin = 0;
int16_t setPin = 9299;

enum pushButton {
	none, chequing, savings, ok, cancel
};
//enumerated values for use with if
//(pbPressed == value) type conditional
//statements

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void waitForPBRelease(const int16_t pin, const char port) {
	while (deBounceReadPin(pin, port, 10) == 0) {
		//do nothing wait for key press to be released
	}
}

void pushButtonInit(void) {
	deBounceInit(chequingPbPin, 'A', 1); 		//1 = pullup resistor enabled
	deBounceInit(savingsPbPin, 'A', 1); 		//1 = pullup resistor enabled
	deBounceInit(okPbPin, 'A', 1); 			//1 = pullup resistor enabled
	deBounceInit(cancelPbPin, 'A', 1); 		//1 = pullup resistor enabled
}


void displayWelcome(void) {
	char stringBuffer[23] = { 0 };
	HD44780_ClrScr();
	HD44780_GotoXY(0, 0);
	snprintf(stringBuffer, 23, "Debit Machine");
	HD44780_PutStr(stringBuffer);
	HD44780_GotoXY(0, 1);
	snprintf(stringBuffer, 23, "SAI TEJA");
	HD44780_PutStr(stringBuffer);
}


void displayAmount(float amount) {
	char stringBuffer[16] = { 0 };
	HD44780_ClrScr();
	snprintf(stringBuffer, 16, "$%.2f", amount);
	HD44780_PutStr(stringBuffer);
}


float checkIfAmountRecd() {
	float debitAmount = 0;
	printf("waiting for amount to be entered\r\n");
	int16_t result = 0;
	result = scanf("%f", &debitAmount);
	if (result == 0)		//then somehow non-float chars were entered
			{						//and nothing was assigned to %f
		fpurge(STDIN_FILENO); //clear the last erroneous char(s) from the input stream
	}
	return debitAmount;
}


int8_t checkOkOrCancel(void) {
	if (deBounceReadPin(cancelPbPin, 'A', 10) == 0) {
		//then the cancel pushbutton has been pressed
		return cancel;
	} else if (deBounceReadPin(okPbPin, 'A', 10) == 0) {
		//then ok pressed
		return ok;
	} else {
		return none; //as ok or cancel was not pressed.
	}
}

int8_t savingsChequingOrCancel(void) {
	if (deBounceReadPin(savingsPbPin, 'A', 10) == 0) {
		//then the cancel pushbutton has been pressed
		return savings;
	} else if (deBounceReadPin(chequingPbPin, 'A', 10) == 0) {
		//then ok pressed
		return chequing;
	} else if (deBounceReadPin(cancelPbPin, 'A', 10) == 0) {
		//then ok pressed
		return cancel;
	} else {
		return none; //as ok or cancel was not pressed.
	}
}


void displayOkCancel(void) {
	char stringBuffer[16] = { 0 };
	HD44780_GotoXY(0, 1); //move to second line first position
	snprintf(stringBuffer, 16, "ok or cancel?");
	HD44780_PutStr(stringBuffer);
}


void displaySavingsorChequings() {
	HD44780_ClrScr();
	HD44780_GotoXY(0, 1);
	char stringBuffer1[16] = { 0 };
	snprintf(stringBuffer1, 16, "S or C");
	HD44780_PutStr(stringBuffer1);
}


void displayEnterPin() {
	HD44780_ClrScr();
	HD44780_GotoXY(0, 0);
	char stringBuffer1[16] = { 0 };
	snprintf(stringBuffer1, 16, "Enter the Pin");
	HD44780_PutStr(stringBuffer1);
}


void displayPinOk() {
	HD44780_ClrScr();
	HD44780_GotoXY(0, 0);
	char stringBuffer4[16] = { 0 };
	snprintf(stringBuffer4, 16, "Pin Ok");
	HD44780_PutStr(stringBuffer4);
}


void displayTransactionCancel() {
	HD44780_ClrScr();
	HD44780_GotoXY(0, 0);
	char stringBuffer5[18] = { 0 };
	snprintf(stringBuffer5, 18, "Transaction Cncl");
	HD44780_PutStr(stringBuffer5);
}


void displayProcessing() {
	HD44780_ClrScr();
	HD44780_GotoXY(0, 0);
	char stringBuffer2[16] = { 0 };
	snprintf(stringBuffer2, 16, "Its Processing");
	HD44780_PutStr(stringBuffer2);
}


void displayThankYou() {
	HD44780_ClrScr();
	HD44780_GotoXY(0, 0);
	char stringBuffer3[25] = { 0 };
	snprintf(stringBuffer3, 25, "Thankyou for Transcation");
	HD44780_PutStr(stringBuffer3);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */

	HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	HD44780_Init();
	pushButtonInit();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		float amount = 0;             	//used to hold the transaction amount
		//static int8_t transactionState = 1;
		int8_t pbPressed = 0;  //will hold pushbutton defined above depending on
							   //the pushbutton pressed
		/*states:   1   display Welcome Screen, wait for $ amount input from
		 Serial port
		 2   @ amount Received, waiting for Ok or Cancel button
		 3   OK received, waiting for chequing or Savings button
		 4   C or S received, waiting for PIN to be entered from
		 Serial Port
		 5   Pin Correct, send transaction data to bank. Waiting
		 for OK back from Bank If OK from Bank received. Print
		 Reciept, Record transaction. Move back to State 1.
		 6   Cancel Pressed. Display "Transaction Cancelled" back to
		 state 1
		 */

		switch (transactionState) {

		case 1:

			displayWelcome(); // display welcome

			//checking if an amount has been received
			amount = checkIfAmountRecd();
			printf("entered!\r\n");

			if (amount != 0)        //returns a 0 if an transaction amount has
					{ 					//NOT been received on the serial port.
				displayAmount(amount); //but if we're we've received a debitAmount
				displayOkCancel();	//so display it and the prompt ok or cancel
				transactionState = 2;//and do that before we move on to state 2
			}
			break;

		case 2:

			pbPressed = checkOkOrCancel(); // check for ok or cancel pressed

			if (pbPressed != none) {
				if (pbPressed == cancel) {
					//then cancel was pressed.
					printf("Cancel Pressed\r\n");
					HD44780_ClrScr();
					// Using timer to indicate Cancel is pressed
					for (int32_t freq = 488; freq < 550; freq = freq + 5) {
						HAL_Delay(200);
					}
					HAL_Delay(300);

					transactionState = 1;
				} else if (pbPressed == ok) {
					//then ok pressed
					printf("OK Pressed\r\n");
					displaySavingsorChequings(); // displays chequings savings or cancel
					transactionState = 3;

				}

			}
			break;

		case 3:

			pbPressed = savingsChequingOrCancel();

			if (pbPressed != none) {
				if (pbPressed == savings) {
					//then savings was pressed.
					printf("Savings Pressed\r\n");
					transactionState = 4; // go to the next state
				} else if (pbPressed == chequing) {
					//then chequing  pressed
					printf("Chequing Pressed\r\n"); // go to the next state
					transactionState = 4;

				} else if (pbPressed == cancel) {
					printf("Cancel pressed\r\n");

					// Using timer to indicate Cancel is pressed
					for (int32_t freq = 488; freq < 550; freq = freq + 5) {
						HAL_Delay(200);
					}
					HAL_Delay(300);

					transactionState = 1; // go to the state 1
				}
			}
			break;

		case 4:

			displayEnterPin(); // displays Enter the pin on lcd

			printf("Please enter the pin\r\n");
			scanf("%hd", &pin);
			transactionState = 5; // go to state 5

			break;

		case 5:

			if (pin == setPin) {
				displayPinOk(); // displays pin ok on lcd
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET); // illuminates Green led
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);

				transactionState = 6; // go to the state 6

			} else {

				displayTransactionCancel();

				printf("pin not correct\r\n");
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET); // illuminates Red led
				HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET);

				// Using timer to indicate wrong pin

				for (int32_t freq = 488; freq < 550; freq = freq + 3) {
					HAL_Delay(600);
				}
				HAL_Delay(250);

				transactionState = 1; // go to state 1
			}
			break;

		case 6:

			displayProcessing(); // displays its processing on the lcd
			HAL_Delay(2500);

			displayThankYou(); // displays thank you on lcd
			HAL_Delay(2500);
			transactionState = 1; // go to the state 1

			break;
		} //closing brace for switch
	}

}
  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 100;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LD3_Pin */
  GPIO_InitStruct.Pin = LD3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD3_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
